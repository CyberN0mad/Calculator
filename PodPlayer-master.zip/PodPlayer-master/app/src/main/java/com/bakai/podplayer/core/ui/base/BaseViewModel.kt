package com.bakai.podplayer.core.ui.base

import androidx.lifecycle.ViewModel

open class BaseViewModel : ViewModel()