package in.insideandroid.biometricauthproject;

//custom interface to get update from biometric dialog
public interface BiometricListener {
    void onSuccess();
    void onFailed();
}
