package com.hfad.bdcalculator.ui.fragments.convertFragments.temperature

import com.hfad.bdcalculator.core.ui.base.BaseViewModel

class TemperatureViewModel: BaseViewModel() {}