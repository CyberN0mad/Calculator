package com.hfad.bdcalculator.ui.main

import com.hfad.bdcalculator.core.ui.base.BaseViewModel
import com.hfad.bdcalculator.data.repository.MainRepo

class MainViewModel(private val repository: MainRepo): BaseViewModel() {
}