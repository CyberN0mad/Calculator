package com.hfad.bdcalculator.ui.fragments.convertFragments.speed

import com.hfad.bdcalculator.core.ui.base.BaseViewModel

class SpeedViewModel: BaseViewModel() {
}