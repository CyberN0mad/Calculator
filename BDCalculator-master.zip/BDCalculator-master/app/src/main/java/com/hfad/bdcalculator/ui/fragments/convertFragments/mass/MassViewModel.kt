package com.hfad.bdcalculator.ui.fragments.convertFragments.mass
import com.hfad.bdcalculator.core.ui.base.BaseViewModel

class MassViewModel: BaseViewModel() {}