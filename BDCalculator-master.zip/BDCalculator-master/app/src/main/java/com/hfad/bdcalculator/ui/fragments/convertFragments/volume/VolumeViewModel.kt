package com.hfad.bdcalculator.ui.fragments.convertFragments.volume
import com.hfad.bdcalculator.core.ui.base.BaseViewModel

class VolumeViewModel: BaseViewModel() {}