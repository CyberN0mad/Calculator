package com.hfad.bdcalculator.core.ui.base

import androidx.lifecycle.ViewModel

open class BaseViewModel : ViewModel() {}