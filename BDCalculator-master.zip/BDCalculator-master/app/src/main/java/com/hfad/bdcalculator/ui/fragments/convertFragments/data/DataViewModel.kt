package com.hfad.bdcalculator.ui.fragments.convertFragments.data

import com.hfad.bdcalculator.core.ui.base.BaseViewModel

class DataViewModel: BaseViewModel() {}