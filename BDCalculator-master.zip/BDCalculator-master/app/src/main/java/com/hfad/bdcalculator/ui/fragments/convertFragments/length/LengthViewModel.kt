package com.hfad.bdcalculator.ui.fragments.convertFragments.length

import com.hfad.bdcalculator.core.ui.base.BaseViewModel

class LengthViewModel: BaseViewModel() {}